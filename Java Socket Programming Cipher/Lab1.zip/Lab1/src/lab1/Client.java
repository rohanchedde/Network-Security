package lab1;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        String hostName = "localhost";
        int portNumber = 12345;

        try (Socket socket = new Socket(hostName, portNumber);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Connected to Siri Server.");
            String userInput;

            while (true) {
                System.out.print("Enter a message (or 'exit' to quit): ");
                userInput = scanner.nextLine();
                if ("exit".equalsIgnoreCase(userInput)) {
                    break;
                }

                // Encrypt the message and send it to the server
                String encryptedMessage = VigenereCipher.encrypt(userInput);
                out.println(encryptedMessage);
                System.out.println("Encrypted message sent to server: " + encryptedMessage);

                // Receive encrypted response and decrypt it
                String encryptedResponse = in.readLine();
                System.out.println("Encrypted response from server: " + encryptedResponse);
                String decryptedResponse = VigenereCipher.decrypt(encryptedResponse);
                System.out.println("Decrypted response: " + decryptedResponse);
            }
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
