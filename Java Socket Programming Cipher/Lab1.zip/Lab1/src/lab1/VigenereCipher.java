package lab1;

public class VigenereCipher {
    private static final String KEY = "TMU";

    public static String encrypt(String text) {
        StringBuilder result = new StringBuilder();
        text = text.toUpperCase();
        int keyIndex = 0;

        for (char c : text.toCharArray()) {
            if (Character.isLetter(c)) {
                char encryptedChar = (char) ((c + KEY.charAt(keyIndex) - 2 * 'A') % 26 + 'A');
                result.append(encryptedChar);
                keyIndex = (keyIndex + 1) % KEY.length();
            } else {
                result.append(c);
            }
        }

        return result.toString();
    }

    public static String decrypt(String text) {
        StringBuilder result = new StringBuilder();
        text = text.toUpperCase();
        int keyIndex = 0;

        for (char c : text.toCharArray()) {
            if (Character.isLetter(c)) {
                char decryptedChar = (char) ((c - KEY.charAt(keyIndex) + 26) % 26 + 'A');
                result.append(decryptedChar);
                keyIndex = (keyIndex + 1) % KEY.length();
            } else {
                result.append(c);
            }
        }

        return result.toString();
    }
}
