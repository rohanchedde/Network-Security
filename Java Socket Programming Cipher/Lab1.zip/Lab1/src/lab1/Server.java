package lab1;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class Server {
    private static final int PORT_NUMBER = 12345;

    public static void main(String[] args) {
        ArrayList<String> questions = new ArrayList<>();
        ArrayList<String> answers = new ArrayList<>();
        
        // Predefined questions and answers
        questions.add("Who created you");
        answers.add("I was created by apple");

        questions.add("What does Siri mean");
        answers.add("victory and beautiful");

        questions.add("Are you a robot");
        answers.add("I am a virtual assistant");

        System.out.println("Siri Server is running...");
        
        try (ServerSocket serverSocket = new ServerSocket(PORT_NUMBER)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected: " + clientSocket.getInetAddress());
                // Pass the socket and Q&A lists to the client handler
                ClientHandler clientHandler = new ClientHandler(clientSocket, questions, answers);
                new Thread(clientHandler).start(); // Start a new thread for each client
            }
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}

class ClientHandler implements Runnable {
    private final Socket clientSocket;
    private final ArrayList<String> questions;
    private final ArrayList<String> answers;

    public ClientHandler(Socket clientSocket, ArrayList<String> questions, ArrayList<String> answers) {
        this.clientSocket = clientSocket;
        this.questions = questions;
        this.answers = answers;
    }

    @Override
    public void run() {
        try (PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {

            String question;
            while ((question = in.readLine()) != null) {
                System.out.println("Encrypted message from client: " + question);
                String decryptedMessage = VigenereCipher.decrypt(question);
                System.out.println("Decrypted message: " + decryptedMessage);

                // Find the answer to the question
                String answer = "Sorry, I don't understand";
                for (int i = 0; i < questions.size(); i++) {
                    if (questions.get(i).equalsIgnoreCase(decryptedMessage)) {
                        answer = answers.get(i);
                        break;
                    }
                }

                String encryptedResponse = VigenereCipher.encrypt(answer);
                System.out.println("Response sent to client: " + answer);
                out.println(encryptedResponse); // Send encrypted response to client
            }
        } catch (IOException e) {
            System.err.println("Client handler error: " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                System.err.println("Error closing client socket: " + e.getMessage());
            }
            System.out.println("Client disconnected.");
        }
    }
}
